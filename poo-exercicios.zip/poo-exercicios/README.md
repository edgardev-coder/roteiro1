# Exercícios de POO (C#)

Cada pasta é um projeto independente. Para rodar (precisa do .NET 8 SDK):

    cd Exercicio01-Funcionario
    dotnet run
